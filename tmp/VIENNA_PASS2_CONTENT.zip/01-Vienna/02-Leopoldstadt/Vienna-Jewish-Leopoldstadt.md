---
type: place
name: Jewish Leopoldstadt
name_he: לאופולדשטאדט היהודית
name_local: Jüdisches Leopoldstadt
city: Vienna
country: Austria
district: Leopoldstadt
visit_status: visited
content_status: first-complete-build
priority: high
personal_rating: 5
themes: [jewish-history,holocaust,local-life]
tags: [place, vienna]
hero_image:
  provider: wikimedia_commons
  storage: remote
  file: "Wien 1830 Vasquez Leopoldstadt Karmeliterviertel.jpg"
  remote_url: "https://commons.wikimedia.org/wiki/Special:FilePath/Wien%201830%20Vasquez%20Leopoldstadt%20Karmeliterviertel.jpg?width=1600"
  source_page: "https://commons.wikimedia.org/wiki/File:Wien%201830%20Vasquez%20Leopoldstadt%20Karmeliterviertel.jpg"
  author: "Peter Gugerell"
  license: "Public Domain"
  license_url: "https://creativecommons.org/publicdomain/mark/1.0/"
  verified: 2026-08-27
visit_duration:
  minimum_minutes: 45
  recommended_minutes: 90
nearby_places:
  - page: Karmelitermarkt
    name_he: קרמליטרמרקט
    distance_m: 150
    walk_minutes: 2
  - page: Karmeliterviertel
    name_he: קרמליטרפירטל
    distance_m: 150
    walk_minutes: 2
  - page: Hotel-IMLAUER-Wien
    name_he: מלון IMLAUER Wien
    distance_m: 400
    walk_minutes: 5
  - page: Taborstrasse
    name_he: טאבורשטראסה
    distance_m: 400
    walk_minutes: 5
verification:
  general: 2026-08-27
recheck_before_visit:
  - opening_hours
  - tickets
  - transport
---
# לאופולדשטאדט היהודית (Jüdisches Leopoldstadt) - מרחב החיים היהודיים ההיסטורי והעכשווי ברובע השני

![לאופולדשטאדט היהודית (Jüdisches Leopoldstadt)](https://commons.wikimedia.org/wiki/Special:FilePath/Wien%201830%20Vasquez%20Leopoldstadt%20Karmeliterviertel.jpg?width=1600)

*צילום: Peter Gugerell. מקור: [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Wien%201830%20Vasquez%20Leopoldstadt%20Karmeliterviertel.jpg). רישיון: [Public Domain](https://creativecommons.org/publicdomain/mark/1.0/).*

## הקהילה בתוך שגרת הטיול

בשהות שלנו, לאופולדשטאדט הייתה גם סביבת מגורים זמנית וגם מקום שבו חיפשנו מזון ושירותים. החנויות והנוכחות היהודית ברחוב נתנו להיסטוריה המקומית המשך בהווה. הסיפור האישי נמצא ב[[Leopoldstadt-Local-Life-Route|מסלול חיי השכונה]], שנצבר לאורך כמה ימים.

ההבחנה מול [[Jewish-Vienna-Route|יודנפלאץ]] חשובה. שם עסקנו במוזיאון, בשרידים ובזיכרון; כאן החיים הפעילים הם חלק מן העניין. אין פירוש הדבר שהעבר נעדר מן הרחוב, או שהקהילה הנוכחית זהה לזו שלפני המלחמה. החיבור נוצר דווקא כשמכירים גם את השינוי.

אפשר לקרוא חנות כשרה או מוסד קהילתי מתוך תפקידם למי שמשתמש בהם. הם מאפשרים שגרה, קשרים ובחירה מעשית. אין בתיעוד שלנו אישור כניסה לכל מוסד המוזכר ברקע, ולא כל שאלה על מסעדה מוכיחה שאכלנו בה. [[Food-and-Kosher-Reference|מדריך האוכל]] שומר בנפרד את הבחירות המתועדות ואת הבדיקות הנדרשות.

<!-- image-placeholder:
subject=רחוב או שילוט עסקי הקשורים לסביבה היהודית כפי שתועדו בטיול
context=לאופולדשטאדט היהודית בהווה
placement=אחרי הקשר בין קהילה לשגרה
priority=HIGH
suggested_count=2
-->

מקור ההתנסות: שיחות הטיול שמופו ב־Pass 1. ההיסטוריה והרקע הקהילתי נשמרים במקורות שבסוף העמוד.

## למה זה מעניין אותנו

כאן הסיפור היהודי אינו רק מוזיאון. זה רובע שהיה מרכז יהודי חשוב, נפגע קשות בשואה, ובו מתקיימים גם היום חיים יהודיים נראים לעין.

**דירוג אישי: ⭐⭐⭐⭐⭐**

## הסיפור

לאופולדשטאדט היהודית (Jüdisches Leopoldstadt) אינה אתר אחד אלא מרחב עירוני שבו אפשר לקרוא כמה מאות שנים של היסטוריה יהודית. אפילו שם הרובע קשור לסיפור הזה. בשנת 1670 גירש הקיסר לאופולד הראשון את היהודים מאזור Unterer Werd, שבו התקיימה קהילה יהודית משמעותית; לאחר הגירוש שונה שם האזור ל-Leopoldstadt. כלומר, שם שכונה שנשמע היום תמים לחלוטין נולד מתוך אירוע של עקירה.

היהודים חזרו לווינה בהדרגה, והמצב השתנה שוב עם צו הסובלנות של יוזף השני בשנת 1782 ועם תהליכי האמנציפציה של המאה ה־19. לאופולדשטאדט הפכה לאחד המרכזים הגדולים של החיים היהודיים בעיר. היא משכה משפחות ותיקות לצד מהגרים מחלקים אחרים של האימפריה, במיוחד מן המזרח. פעלו כאן בתי כנסת גדולים, בתי תפילה קטנים, מוסדות חינוך, אגודות, בתי עסק, עיתונים וארגוני סיוע.

הקהילה לא הייתה אחידה, וזו נקודה שכדאי לזכור תוך כדי הליכה. חיו כאן יהודים אורתודוקסים וחילונים, ציונים וסוציאליסטים, בעלי עסקים ופועלים, דוברי גרמנית לצד מהגרים שהביאו איתם מסורות ושפות אחרות. לאופולדשטאדט הייתה פחות "גטו" במובן התיירותי ויותר מערכת אקולוגית עירונית יהודית שלמה.

האנשלוס בשנת 1938 הפך את הרובע לאחד המוקדים של האלימות נגד יהודי וינה. בתי כנסת ובתי תפילה נהרסו בפוגרום נובמבר, רכוש הוחרם, אנשים גורשו מבתיהם ורבים נאלצו לברוח או נשלחו אל מותם. העובדה שהיום קשה לפעמים לזהות ברחוב את קנה המידה של העולם שהיה כאן היא חלק מן הסיפור: חלק גדול מן התשתית הפיזית והחברתית פשוט נמחק.

אחרי 1945 נבנתה הקהילה מחדש בהיקף קטן בהרבה. הגירה ממזרח אירופה ובהמשך מברית המועצות לשעבר תרמה להתחדשות ולגיוון שלה. כיום חלק גדול מן המוסדות היהודיים של וינה נמצא שוב ברובע השני: בתי כנסת, מוסדות חינוך, שירותים קהילתיים, חנויות ומסעדות כשרות. לכן ההליכה כאן אינה צריכה להיות רק מסלול של "איפה היה". היא גם הזדמנות לראות קהילה שחיה בעיר עכשיו.

## מה לחפש במקום

- לא לחפש "רובע יהודי עתיק" משומר. רוב הסיפור נמצא בשילוב בין כתובות זיכרון, בניינים רגילים ומוסדות פעילים.
- לשים לב לשמות רחובות, ללוחות זיכרון ולסימנים של בתי כנסת ובתי תפילה שנהרסו.
- באזור [[Karmeliterviertel|קרמליטרפירטל]] ו-[[Karmelitermarkt|קרמליטרמרקט]] לראות כיצד חיים יהודיים מתקיימים לצד שכונה עירונית רגילה, בתי קפה ושוק.
- לכבד מוסדות פעילים ולא להתייחס אליהם כאטרקציה. אבטחה בכניסה למוסדות יהודיים היא חלק מן המציאות הנוכחית, לא תפאורה.

## זמן שכדאי להקדיש

- **מינימום:** כ־45 דקות
- **מומלץ:** כשעה וחצי

## מה קרוב לכאן

- [[Karmelitermarkt|קרמליטרמרקט (Karmelitermarkt)]] — כ־150 מטר, כ־2 דקות הליכה. לאוכל, שוק שכונתי ואווירה יומיומית של Leopoldstadt. [קח אותי לשם](https://www.google.com/maps/dir/?api=1&destination=Karmelitermarkt%2C+Vienna%2C+Austria&travelmode=walking)
- [[Karmeliterviertel|קרמליטרפירטל (Karmeliterviertel)]] — כ־150 מטר, כ־2 דקות הליכה. להמשך הליכה בשכונה ולא רק בין נקודות תיירות. [קח אותי לשם](https://www.google.com/maps/dir/?api=1&destination=Karmeliterviertel%2C+Vienna%2C+Austria&travelmode=walking)
- [[Hotel-IMLAUER-Wien|מלון IMLAUER Wien (Hotel IMLAUER Wien)]] — כ־400 מטר, כ־5 דקות הליכה. לחזרה לנקודת הבסיס שלנו ב-Leopoldstadt. [קח אותי לשם](https://www.google.com/maps/dir/?api=1&destination=Hotel+IMLAUER+Wien%2C+Vienna%2C+Austria&travelmode=walking)
- [[Taborstrasse|טאבורשטראסה (Taborstraße)]] — כ־400 מטר, כ־5 דקות הליכה. לציר הרחוב שמחבר את המלון והחיים המקומיים אל מרכז וינה. [קח אותי לשם](https://www.google.com/maps/dir/?api=1&destination=Taborstra%C3%9Fe%2C+Vienna%2C+Austria&travelmode=walking)

## מידע מעשי

זהו מרחב שכונתי ולא אתר בעל שעות פתיחה אחידות. ביקור בתוך בתי כנסת, מוסדות קהילה או מרכזים יהודיים דורש בדיקה נפרדת ולעיתים תיאום מראש. נקודת המוצא בוינה היא [[Hotel-IMLAUER-Wien|מלון IMLAUER Wien (Hotel IMLAUER Wien)]].

## מקורות

- [Stadt Wien](https://www.wien.gv.at/en/living-together/jewish-vienna-history-equal-rights)
- [Stadt Wien](https://www.wien.gv.at/en/living-together/jewish-vienna-history-nationalsocialism)
- [Stadt Wien](https://www.wien.gv.at/en/living-together/jewish-community-vienna)
- [ikg-wien.at](https://www.ikg-wien.at/)
